export interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  journalist?: string;
  category: string;
  image: string;
}
