import { useState, useEffect, useMemo } from "react";
import { NewsItem } from "../types";
import NewsCard from "./NewsCard";
import newsData from "../data/news.json";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, Calendar, User, Tag, Share2, Moon, Sun, Languages, 
  ArrowLeft, Send, Twitter, MessageCircle, Mail, Filter, SortDesc, SortAsc, LayoutDashboard
} from "lucide-react";
import { PriceTicker } from './PriceTicker';

const translations = {
// ... (keeping translations as they are)
  pt: {
    heroTitle: "DeFi Bank",
    heroSubtitle: "News",
    heroDesc: "Sua fonte definitiva de informações sobre o ecossistema DeFi Bank e o mercado cripto global.",
    all: "Todas",
    latest: "Mais recentes",
    oldest: "Mais antigas",
    source: "Fonte",
    journalist: "Jornalista",
    share: "Compartilhar",
    newsletterTitle: "Fique por dentro",
    newsletterDesc: "Assine nossa newsletter e receba as principais notícias do mercado diretamente no seu e-mail.",
    subscribe: "Assinar Agora",
    placeholderEmail: "Seu melhor e-mail",
    readMore: "Ler mais",
    back: "Voltar",
    noNews: "Nenhuma notícia encontrada.",
    filterBy: "Filtrar por",
    sortBy: "Ordenar por",
    author: "Autor",
    date: "Data"
  },
  en: {
    heroTitle: "DeFi Bank",
    heroSubtitle: "News",
    heroDesc: "Your ultimate source of information about the DeFi Bank ecosystem and the global crypto market.",
    all: "All",
    latest: "Latest",
    oldest: "Oldest",
    source: "Source",
    journalist: "Journalist",
    share: "Share",
    newsletterTitle: "Stay Tuned",
    newsletterDesc: "Subscribe to our newsletter and get the top market news directly in your inbox.",
    subscribe: "Subscribe Now",
    placeholderEmail: "Your best email",
    readMore: "Read more",
    back: "Back",
    noNews: "No news found.",
    filterBy: "Filter by",
    sortBy: "Sort by",
    author: "Author",
    date: "Date"
  }
};

export default function PublicFeed({ onViewDashboard }: { onViewDashboard: () => void }) {
  const [news, setNews] = useState<NewsItem[]>(newsData as NewsItem[]);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);
  const [filter, setFilter] = useState("Todas");
  const [sourceFilter, setSourceFilter] = useState("Todas");
  const [sortOrder, setSortOrder] = useState<"desc" | "asc">("desc");
  const [lang, setLang] = useState<"pt" | "en">("pt");
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  const t = translations[lang];

  useEffect(() => {
    fetchNews();
    // Apply theme to body
    document.documentElement.classList.toggle("light", theme === "light");
    
    // Check for news ID in URL
    const params = new URLSearchParams(window.location.search);
    const newsId = params.get("news");
    if (newsId && news.length > 0) {
      const item = news.find(n => n.id === newsId);
      if (item) setSelectedNews(item);
    }
  }, [theme, news.length]);

  const fetchNews = async () => {
    try {
      const res = await fetch("/api/news");
      if (res.ok) {
        const data = await res.json();
        setNews(data);
      }
    } catch (error) {
      console.log("Running in static mode or API unavailable");
    }
  };

  const categories = useMemo(() => ["Todas", ...new Set(news.map(item => item.category))], [news]);
  const sources = useMemo(() => ["Todas", ...new Set(news.map(item => item.author))], [news]);

  const filteredAndSortedNews = useMemo(() => {
    let result = [...news];
    
    if (filter !== "Todas") {
      result = result.filter(item => item.category === filter);
    }
    
    if (sourceFilter !== "Todas") {
      result = result.filter(item => item.author === sourceFilter);
    }
    
    result.sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortOrder === "desc" ? dateB - dateA : dateA - dateB;
    });
    
    return result;
  }, [news, filter, sourceFilter, sortOrder]);

  const handleShare = (platform: string, item: NewsItem) => {
    // Link para a página de SEO que gera o Rich Preview
    const shareUrl = `${window.location.origin}/share/${item.id}.html`;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(item.title)}&url=${encodeURIComponent(shareUrl)}`);
        break;
      case 'whatsapp':
        // No WhatsApp, enviamos apenas o link para que ele gere o preview automático
        window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareUrl)}`);
        break;
      case 'telegram':
        window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(item.title)}`);
        break;
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${theme === 'dark' ? 'bg-black' : 'bg-slate-50'}`}>
      {/* Header / Controls */}
      <header className="sticky top-0 z-40 glass-card border-b border-white/5 py-4 px-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <img src="https://i.imgur.com/VYool5N.png" alt="DeFi Bank" className="h-8 w-auto" />
            <span className="font-space-grotesk font-bold text-xl hidden md:block tracking-tight">News</span>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={onViewDashboard}
              className="p-2 rounded-full hover:bg-white/10 transition-colors flex items-center gap-2 text-sm font-medium text-brand-orange"
              title="Voltar ao Dashboard"
            >
              <LayoutDashboard size={20} />
              <span className="hidden md:block">Dashboard</span>
            </button>
            <button 
              onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')}
              className="p-2 rounded-full hover:bg-white/10 transition-colors flex items-center gap-2 text-sm font-medium"
            >
              <Languages size={20} />
              <span className="uppercase">{lang}</span>
            </button>
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-orange/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12"
          >
            <h1 className="text-5xl md:text-7xl font-extrabold font-space-grotesk mb-6">
              {t.heroTitle} <span className="gradient-text">{t.heroSubtitle}</span>
            </h1>
            <p className="text-xl opacity-60 max-w-2xl mx-auto">
              {t.heroDesc}
            </p>
          </motion.div>

          {/* Promotional Banner */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-4xl mx-auto mb-16 p-6 rounded-3xl gradient-bg relative overflow-hidden group cursor-pointer"
          >
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-white text-left">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center overflow-hidden flex-shrink-0">
                  <img src="https://i.imgur.com/sd3LZoV.png" alt="DeFi Bank" className="w-10 h-10 object-contain" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold font-space-grotesk mb-2">DeFi Bank Card Visa</h3>
                  <p className="opacity-90">O cartão perfeito para quem vive no mundo Web3. Use seus criptoativos em qualquer lugar.</p>
                </div>
              </div>
              <button className="px-8 py-3 bg-white text-brand-orange font-bold rounded-xl whitespace-nowrap hover:scale-105 transition-transform">
                Saiba Mais
              </button>
            </div>
          </motion.div>
        </div>

        {/* Price Ticker */}
        <div className="mb-12">
          <PriceTicker />
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
          {/* Filters & Sorting */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12 p-4 glass-card rounded-2xl">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 text-sm opacity-50 mr-2">
                <Filter size={16} /> {t.filterBy}:
              </div>
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                    filter === cat 
                      ? "gradient-bg text-white" 
                      : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {cat === "Todas" ? t.all : cat}
                </button>
              ))}
              <div className="w-px h-6 bg-white/10 mx-2 hidden md:block" />
              {sources.map(src => (
                <button
                  key={src}
                  onClick={() => setSourceFilter(src)}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                    sourceFilter === src 
                      ? "bg-brand-orange text-white" 
                      : "bg-white/5 hover:bg-white/10"
                  }`}
                >
                  {src === "Todas" ? t.source : src}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm opacity-50">
                <SortDesc size={16} /> {t.sortBy}:
              </div>
              <button 
                onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 text-xs font-bold hover:bg-white/10 transition-colors"
              >
                {sortOrder === 'desc' ? t.latest : t.oldest}
                {sortOrder === 'desc' ? <SortDesc size={14} /> : <SortAsc size={14} />}
              </button>
            </div>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAndSortedNews.map(item => (
              <NewsCard 
                key={item.id} 
                news={item} 
                onClick={() => setSelectedNews(item)}
              />
            ))}
          </div>
          
          {filteredAndSortedNews.length === 0 && (
            <div className="text-center py-20 opacity-30">
              {t.noNews}
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-6">
          <div className="glass-card p-12 rounded-[40px] text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 gradient-bg" />
            <h2 className="text-3xl font-bold font-space-grotesk mb-4">{t.newsletterTitle}</h2>
            <p className="opacity-60 mb-8 max-w-md mx-auto">{t.newsletterDesc}</p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input 
                type="email" 
                placeholder={t.placeholderEmail}
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-brand-orange transition-colors"
              />
              <button className="px-8 py-4 gradient-bg text-white font-bold rounded-2xl hover:opacity-90 transition-opacity whitespace-nowrap">
                {t.subscribe}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Immersive News View */}
      <AnimatePresence>
        {selectedNews && (
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className={`fixed inset-0 z-50 overflow-y-auto custom-scrollbar ${theme === 'dark' ? 'bg-black' : 'bg-white'}`}
          >
            <div className="max-w-4xl mx-auto min-h-screen relative">
              {/* Top Bar */}
              <div className="sticky top-0 z-10 flex justify-between items-center p-6 bg-inherit/80 backdrop-blur-md">
                <button 
                  onClick={() => setSelectedNews(null)}
                  className="flex items-center gap-2 text-sm font-bold opacity-60 hover:opacity-100 transition-opacity"
                >
                  <ArrowLeft size={20} /> {t.back}
                </button>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => handleShare('twitter', selectedNews)}
                    className="p-2 rounded-full bg-white/5 hover:bg-brand-orange/20 hover:text-brand-orange transition-colors"
                  >
                    <Twitter size={20} />
                  </button>
                  <button 
                    onClick={() => handleShare('whatsapp', selectedNews)}
                    className="p-2 rounded-full bg-white/5 hover:bg-brand-orange/20 hover:text-brand-orange transition-colors"
                  >
                    <MessageCircle size={20} />
                  </button>
                  <button 
                    onClick={() => handleShare('telegram', selectedNews)}
                    className="p-2 rounded-full bg-white/5 hover:bg-brand-orange/20 hover:text-brand-orange transition-colors"
                  >
                    <Send size={20} />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="px-6 pb-20">
                <div className="relative h-[400px] rounded-[40px] overflow-hidden mb-12 shadow-2xl">
                  <img 
                    src={selectedNews.image} 
                    alt={selectedNews.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  <div className="absolute bottom-10 left-10 right-10">
                    <span className="px-4 py-1.5 rounded-full bg-brand-orange text-white text-sm font-bold mb-6 inline-block">
                      {selectedNews.category}
                    </span>
                    <h1 className="text-4xl md:text-6xl font-extrabold font-space-grotesk text-white leading-tight">
                      {selectedNews.title}
                    </h1>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-8 text-sm opacity-50 mb-12 pb-8 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <Calendar size={20} className="text-brand-orange" />
                    {new Date(selectedNews.date).toLocaleDateString(lang === 'pt' ? 'pt-BR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </div>
                  <div className="flex items-center gap-2">
                    <User size={20} className="text-brand-orange" />
                    <div className="flex flex-col">
                      <span className="font-bold text-inherit opacity-100">{selectedNews.author}</span>
                      {selectedNews.journalist && <span className="text-xs">{t.journalist}: {selectedNews.journalist}</span>}
                    </div>
                  </div>
                </div>

                <div className="prose prose-xl max-w-none">
                  <p className="text-2xl opacity-80 font-medium mb-12 leading-relaxed italic border-l-4 border-brand-orange pl-8">
                    {selectedNews.excerpt}
                  </p>
                  <div className="text-xl opacity-70 leading-relaxed space-y-8 whitespace-pre-wrap">
                    {selectedNews.content}
                  </div>
                </div>

                {/* Bottom Banner */}
                <div className="mt-20 p-10 rounded-[40px] glass-card border-brand-orange/20 flex flex-col md:flex-row items-center gap-8">
                  <div className="w-24 h-24 rounded-3xl flex items-center justify-center overflow-hidden">
                <img src="https://i.imgur.com/sd3LZoV.png" alt="DeFi Bank" className="w-full h-full object-contain" />
              </div>                  <div className="flex-1 text-center md:text-left">
                    <h4 className="text-2xl font-bold mb-2">Abra sua conta DeFi Bank</h4>
                    <p className="opacity-60">Pix para USDT em segundos. O gateway perfeito para sua liberdade financeira.</p>
                  </div>
                  <button className="px-10 py-4 gradient-bg text-white font-bold rounded-2xl hover:scale-105 transition-transform">
                    Começar Agora
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
