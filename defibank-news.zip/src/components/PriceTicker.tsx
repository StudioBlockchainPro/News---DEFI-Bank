import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface CoinData {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
}

export const PriceTicker: React.FC = () => {
  const [coins, setCoins] = useState<CoinData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPrices = async () => {
      try {
        const response = await fetch(
          'https://api.coingecko.com/api/v3/coins/markets?vs_currency=brl&ids=bitcoin,ethereum,binancecoin,solana,ripple,cardano,polkadot,chainlink,polygon,tether-gold&order=market_cap_desc&per_page=10&page=1&sparkline=false'
        );
        const data = await response.json();
        if (Array.isArray(data)) {
          setCoins(data);
        }
      } catch (error) {
        console.error('Error fetching prices:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  if (loading && coins.length === 0) return null;

  // Duplicate coins to create seamless loop
  const displayCoins = [...coins, ...coins];

  return (
    <div className="w-full bg-white/5 border-y border-white/5 py-3 overflow-hidden backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6">
        <div className="relative flex overflow-hidden">
          <motion.div
            animate={{
              x: [0, -100 * coins.length],
            }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear",
            }}
            className="flex gap-12 items-center whitespace-nowrap"
          >
            {displayCoins.map((coin, index) => (
              <div key={`${coin.id}-${index}`} className="flex items-center gap-3 group">
                <img src={coin.image} alt={coin.name} className="w-5 h-5 grayscale group-hover:grayscale-0 transition-all" />
                <span className="font-bold text-sm">{coin.name}</span>
                <span className="text-sm font-mono opacity-80">
                  R$ {coin.current_price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
                <span className={`text-xs font-bold flex items-center gap-1 ${
                  coin.price_change_percentage_24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}>
                  {coin.price_change_percentage_24h >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                  {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
                </span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
};
