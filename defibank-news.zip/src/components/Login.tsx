import React from 'react';
import { LogIn, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginProps {
  onLoginSuccess: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const handleLogin = () => {
    const width = 600;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;
    
    const popup = window.open(
      '/api/auth/google',
      'google_login',
      `width=${width},height=${height},left=${left},top=${top}`
    );

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'AUTH_SUCCESS') {
        onLoginSuccess();
        window.removeEventListener('message', handleMessage);
      }
    };

    window.addEventListener('message', handleMessage);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-12 rounded-[32px] max-w-md w-full text-center border-brand-orange/20"
      >
        <div className="w-20 h-20 bg-brand-orange/10 rounded-3xl flex items-center justify-center mx-auto mb-8">
          <ShieldCheck size={40} className="text-brand-orange" />
        </div>
        
        <h1 className="text-3xl font-bold font-space-grotesk mb-4">Área Restrita</h1>
        <p className="opacity-60 mb-10">
          Apenas administradores autorizados podem acessar o painel de notícias do DeFi Bank.
        </p>

        <button
          onClick={handleLogin}
          className="w-full flex items-center justify-center gap-3 px-8 py-4 rounded-2xl gradient-bg text-white font-bold hover:scale-[1.02] transition-all shadow-xl shadow-brand-orange/20"
        >
          <LogIn size={20} />
          Entrar com Google
        </button>

        <div className="mt-8 pt-8 border-t border-white/5 flex flex-col gap-4">
          <p className="text-xs opacity-40">
            Seu e-mail deve estar previamente autorizado no sistema.
          </p>
          <button
            onClick={() => window.location.href = '/'}
            className="text-sm font-medium text-brand-orange hover:underline"
          >
            Voltar ao Portal Público
          </button>
        </div>
      </motion.div>
    </div>
  );
};
