import { useState, useEffect } from "react";
import { NewsItem } from "../types";
import { Plus, Edit2, Trash2, Save, X, Image as ImageIcon, Globe } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Dashboard({ onViewPortal }: { onViewPortal: () => void }) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState<Partial<NewsItem>>({
    title: "",
    excerpt: "",
    content: "",
    category: "Mercado",
    author: "Equipe DeFi Bank",
    journalist: "",
    image: "https://picsum.photos/seed/crypto/800/400"
  });

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    const res = await fetch("/api/news");
    const data = await res.json();
    setNews(data);
  };

  const handleSave = async () => {
    let updatedNews: NewsItem[];
    
    if (editingId) {
      updatedNews = news.map(item => 
        item.id === editingId ? { ...item, ...formData } as NewsItem : item
      );
    } else {
      const newItem: NewsItem = {
        ...formData,
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
      } as NewsItem;
      updatedNews = [newItem, ...news];
    }

    const res = await fetch("/api/news", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedNews)
    });

    if (res.ok) {
      setNews(updatedNews);
      resetForm();
    } else {
      const error = await res.json();
      alert(error.error || "Erro ao salvar notícia. Verifique se você está logado.");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta notícia?")) return;
    
    const updatedNews = news.filter(item => item.id !== id);
    const res = await fetch("/api/news", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedNews)
    });

    if (res.ok) {
      setNews(updatedNews);
    } else {
      const error = await res.json();
      alert(error.error || "Erro ao excluir notícia.");
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setIsAdding(false);
    setFormData({
      title: "",
      excerpt: "",
      content: "",
      category: "Mercado",
      author: "Equipe DeFi Bank",
      journalist: "",
      image: "https://picsum.photos/seed/crypto/800/400"
    });
  };

  const startEdit = (item: NewsItem) => {
    setEditingId(item.id);
    setFormData(item);
    setIsAdding(true);
  };

  return (
    <div className="max-w-6xl mx-auto p-6 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold font-space-grotesk gradient-text">Dashboard de Notícias</h1>
          <p className="opacity-50">Gerencie as publicações do ecossistema DeFi Bank</p>
        </div>
        <div className="flex items-center gap-3">
          {!isAdding && (
            <>
              <button
                onClick={onViewPortal}
                className="flex items-center gap-2 px-6 py-3 rounded-xl glass-card border-brand-orange/30 text-brand-orange font-bold hover:bg-brand-orange hover:text-white transition-all"
              >
                <Globe size={20} /> Ver Portal
              </button>
              <button
                onClick={() => setIsAdding(true)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl gradient-bg font-bold hover:opacity-90 transition-opacity text-white"
              >
                <Plus size={20} /> Nova Notícia
              </button>
            </>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="glass-card rounded-2xl p-8 mb-12 overflow-hidden border-brand-orange/20"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">{editingId ? "Editar Notícia" : "Criar Nova Notícia"}</h2>
              <button onClick={resetForm} className="opacity-50 hover:opacity-100">
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium opacity-50 mb-1">Título</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors"
                    placeholder="Título da notícia"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium opacity-50 mb-1">Categoria</label>
                    <select
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors"
                    >
                      <option value="Mercado">Mercado</option>
                      <option value="Ecossistema">Ecossistema</option>
                      <option value="Tecnologia">Tecnologia</option>
                      <option value="Tutorial">Tutorial</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium opacity-50 mb-1">Fonte/Autor</label>
                    <select
                      value={formData.author}
                      onChange={e => setFormData({ ...formData, author: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors"
                    >
                      <option value="Equipe DeFi Bank">Equipe DeFi Bank</option>
                      <option value="Terceiros">Terceiros</option>
                      <option value="Parceiro">Parceiro</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium opacity-50 mb-1">Nome do Jornalista (Opcional)</label>
                  <input
                    type="text"
                    value={formData.journalist}
                    onChange={e => setFormData({ ...formData, journalist: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors"
                    placeholder="Ex: João Silva"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium opacity-50 mb-1">URL da Imagem</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={formData.image}
                      onChange={e => setFormData({ ...formData, image: e.target.value })}
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors"
                      placeholder="https://..."
                    />
                    <div className="w-12 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden">
                      {formData.image ? (
                        <img src={formData.image} alt="Preview" className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon size={20} className="opacity-20" />
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium opacity-50 mb-1">Resumo (Excerpt)</label>
                  <textarea
                    value={formData.excerpt}
                    onChange={e => setFormData({ ...formData, excerpt: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors h-24 resize-none"
                    placeholder="Um breve resumo para o card..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium opacity-50 mb-1">Conteúdo Completo</label>
                  <textarea
                    value={formData.content}
                    onChange={e => setFormData({ ...formData, content: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 focus:border-brand-orange outline-none transition-colors h-44 resize-none"
                    placeholder="O corpo da notícia..."
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4 mt-8">
              <button
                onClick={resetForm}
                className="px-6 py-2 rounded-lg border border-white/10 hover:bg-white/5 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-2 px-8 py-2 rounded-lg gradient-bg font-bold hover:opacity-90 transition-opacity text-white"
              >
                <Save size={20} /> Salvar Publicação
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 gap-4">
        {news.map(item => (
          <div key={item.id} className="glass-card rounded-xl p-4 flex items-center justify-between group hover:border-brand-orange/30 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                <img src={item.image} alt="" className="w-full h-full object-cover" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-brand-orange bg-brand-orange/10 px-2 py-0.5 rounded">
                    {item.category}
                  </span>
                  <span className="text-xs text-white/30">{item.date}</span>
                </div>
                <h3 className="font-bold line-clamp-1">{item.title}</h3>
              </div>
            </div>
            
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => startEdit(item)}
                className="p-2 rounded-lg bg-white/5 hover:bg-brand-orange/20 hover:text-brand-orange transition-colors"
                title="Editar"
              >
                <Edit2 size={18} />
              </button>
              <button
                onClick={() => handleDelete(item.id)}
                className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 hover:text-red-500 transition-colors"
                title="Excluir"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
