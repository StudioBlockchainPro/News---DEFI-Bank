import { NewsItem } from "../types";
import { motion } from "motion/react";
import { Calendar, User, Tag, ArrowRight } from "lucide-react";

interface NewsCardProps {
  news: NewsItem;
  onClick?: () => void;
  key?: string;
}

export default function NewsCard({ news, onClick }: NewsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="glass-card rounded-2xl overflow-hidden group cursor-pointer"
      onClick={onClick}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={news.image}
          alt={news.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 rounded-full bg-brand-orange/20 border border-brand-orange/30 text-brand-orange text-xs font-semibold backdrop-blur-md">
            {news.category}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-center gap-4 text-[10px] opacity-50 mb-3">
          <div className="flex items-center gap-1">
            <Calendar size={12} />
            {new Date(news.date).toLocaleDateString('pt-BR')}
          </div>
          <div className="flex items-center gap-1">
            <User size={12} />
            {news.journalist || news.author}
          </div>
        </div>
        
        <h3 className="text-xl font-bold mb-3 group-hover:text-brand-orange transition-colors line-clamp-2">
          {news.title}
        </h3>
        
        <p className="text-white/70 text-sm mb-6 line-clamp-3">
          {news.excerpt}
        </p>
        
        <div className="flex items-center text-brand-orange font-semibold text-sm gap-2">
          Ler mais <ArrowRight size={16} />
        </div>
      </div>
    </motion.div>
  );
}
