// DeFi Bank News Portal - Initial Sync for New Repository
import { useState, useEffect } from "react";
import PublicFeed from "./components/PublicFeed";
import Dashboard from "./components/Dashboard";
import { Login } from "./components/Login";
import { Wallet, LogOut, Loader2 } from "lucide-react";

export default function App() {
  const [view, setView] = useState<"public" | "admin">("public");
  const [auth, setAuth] = useState<{ user: any; isAdmin: boolean } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setAuth(data);
      }
    } catch (e) {
      console.error("Auth check failed", e);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setAuth({ user: null, isAdmin: false });
      setView("public");
    } catch (e) {
      console.error("Logout failed", e);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-brand-orange animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] selection:bg-brand-orange/30 selection:text-brand-orange transition-colors duration-300">
      {/* Admin Header (If logged in) */}
      {auth?.isAdmin && view === "admin" && (
        <div className="bg-brand-orange/10 border-b border-brand-orange/20 py-2 px-6">
          <div className="max-w-7xl mx-auto flex justify-between items-center text-xs font-bold uppercase tracking-wider">
            <div className="flex items-center gap-3">
              {auth.user?.picture && (
                <div className="w-6 h-6 rounded-full overflow-hidden border border-brand-orange/30">
                  <img src={auth.user.picture} alt="" className="w-full h-full object-cover" />
                </div>
              )}
              <span className="opacity-60">Admin: {auth.user?.email}</span>
            </div>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-1 text-brand-orange hover:opacity-80 transition-opacity"
            >
              <LogOut size={14} /> Sair
            </button>
          </div>
        </div>
      )}

      {/* Action Button (Fixed at bottom right) */}
      <div className="fixed bottom-6 right-6 z-[100] flex gap-2">
        <button
          onClick={() => window.open("https://app.defibank.digital", "_blank")}
          className="flex items-center gap-2 px-6 py-3 rounded-full gradient-bg text-white font-bold text-sm hover:scale-105 transition-all shadow-xl shadow-brand-orange/20"
        >
          <Wallet size={18} />
          Criar Conta
        </button>
      </div>

      {/* Main Content */}
      <main>
        {view === "public" ? (
          <PublicFeed onViewDashboard={() => setView("admin")} />
        ) : (
          auth?.isAdmin ? (
            <Dashboard onViewPortal={() => setView("public")} />
          ) : (
            <Login onLoginSuccess={checkAuth} />
          )
        )}
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-[var(--border-color)] bg-[var(--bg-secondary)]">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <img src="https://i.imgur.com/VYool5N.png" alt="DeFi Bank" className="h-10 w-auto" />
          </div>
          
          <div className="opacity-40 text-sm">
            © 2026 DeFi Bank. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
